#!/usr/bin/env python3
"""Fixture tests for the WET-SPEC-002 v0.3 validator. Fully synthetic."""
import copy
import sys

from validate_pdr_v03 import structural_errors, conditional_errors

BASE = {
    "pdr": {
        "id": "PDR-000099",
        "schema_version": "0.3",
        "record_revision": 1,
        "created_at": "2026-08-07T00:00:00Z",
        "updated_at": "2026-08-07T00:00:00Z",
        "production": "Synthetic Production",
        "production_unit": "PU-TEST",
        "decision_artifact": {"type": "soundtrack", "identifier": "TEST CUE"},
        "timeline": {
            "timebase": {"fps": 24, "drop_frame": False},
            "placements": [
                {"lane": -4, "in_rational": "50381/60s", "out_rational": "11977/12s",
                 "in_tc": "00:13:59:16", "out_tc": "00:16:38:02", "duration_s": "158.400s",
                 "source_evidence": "EV-XML-001"},
                {"lane": -1, "in_rational": "16763/12s", "out_rational": "59059/40s"},
            ],
        },
        "objective": "Synthetic objective.",
        "evidence": [
            {"id": "EV-XML-001", "type": "document", "classification": "DERIVED", "confidence": "HIGH",
             "reference": "synthetic/xml", "content_hash": "b" * 64, "custody": "repo:synthetic"},
            {"id": "EV-SESSION-001", "type": "session_record", "classification": "GENERATED",
             "reference": "synthetic/session.md", "custody": "archive:sessions/synthetic-1"},
            {"id": "EV-SUB-001", "type": "other", "classification": "OBSERVED", "confidence": "HIGH",
             "reference": "synthetic/subscription.png", "custody": "repo:synthetic",
             "coverage_period": {"from": "2025-12-07", "to": "2026-12-07"}},
        ],
        "decision_analysis": {
            "selected": {"identifier": "TEST CUE", "selection_basis": "Synthetic basis."},
            "rejected": [{"identifier": "ALT", "rejection_basis": "Synthetic rejection."}],
        },
        "generation": {"method": "Hybrid", "tools": ["Suno"], "session_evidence": ["EV-SESSION-001"]},
        "validation": {"methods": ["Human Approval"], "result": "Passed"},
        "provenance": {"class": "GENERATED", "confidence": "HIGH", "sources": ["EV-SESSION-001"]},
        "rights": {"generator": "Suno", "license_basis": "synthetic", "commercial_use": True},
        "outcome": {"status": "Applied", "artifact_reference": "timeline:test"},
        "approvals": [{"actor": "Test Human", "role": "Producer", "decision": "Approved",
                       "timestamp": "2026-08-07T00:00:00Z"}],
        "status": "Locked",
        "transitions": [
            {"from": "Draft", "to": "Under Review", "actor": "Test Human",
             "timestamp": "2026-08-07T00:00:00Z", "basis": "Evidence complete."},
            {"from": "Under Review", "to": "Locked", "actor": "Test Human",
             "timestamp": "2026-08-07T00:10:00Z",
             "basis": "CR-2/CR-3/CR-4 satisfied; ADR-007 ratified.",
             "evidence_refs": ["EV-XML-001", "EV-SESSION-001"]},
        ],
        "relationships": [],
        "extensions": {},
        "metadata": {"tags": ["test"]},
    }
}


def errs(r):
    return structural_errors(r) + conditional_errors(r)


def expect(name, r, should_pass, must_mention=None):
    e = errs(r)
    ok = (not e) if should_pass else bool(e)
    if ok and must_mention:
        ok = any(must_mention in m for m in e)
    print(("PASS" if ok else "FAIL") + f"  {name}" + ("" if ok else f"  → {e or 'expected violations, got none'}"))
    return ok


def main():
    R = []
    r = copy.deepcopy(BASE)
    R.append(expect("T01 Locked record with full chain + placements conformant", r, True))

    r = copy.deepcopy(BASE)
    r["pdr"]["status"] = "Draft"; r["pdr"]["transitions"] = []
    del r["pdr"]["timeline"]
    R.append(expect("T02 PF-1: Draft temporal record WITHOUT timeline is conformant", r, True))

    r = copy.deepcopy(BASE)
    del r["pdr"]["timeline"]
    R.append(expect("T03 CR-4: Locked temporal record without timeline → violation", r, False, "[CR-4]"))

    r = copy.deepcopy(BASE)
    r["pdr"]["transitions"] = []
    R.append(expect("T04 CR-5: Locked without transition chain → violation", r, False, "[CR-5]"))

    r = copy.deepcopy(BASE)
    r["pdr"]["transitions"][1]["from"] = "Draft"
    R.append(expect("T05 CR-5: broken chain → violation", r, False, "[CR-5]"))

    r = copy.deepcopy(BASE)
    r["pdr"]["transitions"][1]["to"] = "Archived"
    R.append(expect("T06 CR-5: chain end != status → violation", r, False, "[CR-5]"))

    r = copy.deepcopy(BASE)
    r["pdr"]["status"] = "Rejected"
    r["pdr"]["transitions"] = [{"from": "Draft", "to": "Rejected", "actor": "Test Human",
                                "timestamp": "2026-08-07T00:00:00Z", "basis": "Cue rejected at human gate."}]
    R.append(expect("T07 §6a: Rejected is a legal transition target", r, True))

    r = copy.deepcopy(BASE)
    r["pdr"]["evidence"] = [e for e in r["pdr"]["evidence"] if e["type"] != "session_record"]
    r["pdr"]["generation"]["session_evidence"] = []
    R.append(expect("T08 CR-1: AI-assisted beyond Draft, no session record → violation", r, False, "[CR-1]"))

    r = copy.deepcopy(BASE)
    r["pdr"]["evidence"][2]["coverage_period"] = {"from": "2025-12-07"}
    R.append(expect("T09 coverage_period requires from+to → violation", r, False))

    r = copy.deepcopy(BASE)
    r["pdr"]["timeline"]["placements"][0]["in_rational"] = "839.683"
    R.append(expect("T10 PF-3: non-rational observed time → violation", r, False))

    r = copy.deepcopy(BASE)
    r["pdr"]["decision_artifact"]["type"] = "publish"
    R.append(expect("T11 CR-4: non-temporal type with timeline → violation", r, False, "[CR-4]"))

    r = copy.deepcopy(BASE)
    del r["pdr"]["transitions"]
    R.append(expect("T12 §5.1: transitions block required → violation", r, False))

    print(f"\n{sum(R)}/{len(R)} tests passed")
    sys.exit(0 if all(R) else 1)


if __name__ == "__main__":
    main()
