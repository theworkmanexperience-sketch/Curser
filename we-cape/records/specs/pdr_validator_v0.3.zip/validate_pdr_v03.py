#!/usr/bin/env python3
"""WET-SPEC-002 v0.3 PDR validator.

Layers: structural (pdr_schema_v0.3.json) + conditional rules CR-1..CR-5
(v0.3 restatements, incl. PF-1 stage-dependent temporal rule and the §6a
interim transition-chain rule).

Exit 0 = conformant; 1 = violations. Usage: validate_pdr_v03.py <record.yaml> [...]
"""
import json
import sys
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator

SCHEMA_PATH = Path(__file__).parent / "pdr_schema_v0.3.json"

TEMPORAL_TYPES = {"soundtrack", "edit", "vfx", "motion_graphic", "color_grade", "voice_over"}
NON_TEMPORAL_TYPES = {"publish", "licensing"}
REGISTERED_TYPES = TEMPORAL_TYPES | NON_TEMPORAL_TYPES
FILE_EVIDENCE_TYPES = {"review_mp4", "voice_over", "srt", "gpx", "graphics", "document"}
AI_METHOD_MARKERS = ("ai", "suno", "hybrid", "generated", "claude", "llm")
INITIAL_STATE = "draft"


def structural_errors(record: dict) -> list:
    schema = json.loads(SCHEMA_PATH.read_text())
    v = Draft202012Validator(schema)
    return [
        f"[SCHEMA] {'/'.join(str(p) for p in e.absolute_path) or '<root>'}: {e.message}"
        for e in sorted(v.iter_errors(record), key=lambda e: list(e.absolute_path))
    ]


def conditional_errors(record: dict) -> list:
    errors = []
    pdr = record.get("pdr", {})
    status = str(pdr.get("status", "")).strip()
    status_l = status.lower()
    evidence = pdr.get("evidence", []) or []
    generation = pdr.get("generation", {}) or {}
    provenance = pdr.get("provenance", {}) or {}
    transitions = pdr.get("transitions", []) or []

    # CR-1 — AI-assisted beyond Draft requires session evidence with custody
    method = str(generation.get("method", "")).lower()
    ai_involved = provenance.get("class") == "GENERATED" or any(m in method for m in AI_METHOD_MARKERS)
    if ai_involved and status_l != INITIAL_STATE:
        session_entries = [e for e in evidence if e.get("type") == "session_record"]
        ok = any(e.get("custody") and str(e["custody"]).strip() and "tbd" not in str(e["custody"]).lower()
                 and "pending" not in str(e["custody"]).lower() for e in session_entries)
        referenced = set(generation.get("session_evidence") or [])
        linked = any(e.get("id") in referenced for e in session_entries)
        if not session_entries:
            errors.append("[CR-1] AI-assisted decision beyond Draft has no session_record evidence entry.")
        elif not ok:
            errors.append("[CR-1] session_record evidence lacks a resolvable custody pointer.")
        elif not linked:
            errors.append("[CR-1] generation.session_evidence does not reference the session_record evidence ID.")

    # CR-2 — custody + classification at Locked
    if status_l == "locked":
        for e in evidence:
            eid = e.get("id", "<no-id>")
            hash_val = str(e.get("content_hash", "") or "")
            custody = str(e.get("custody", "") or "")
            if e.get("type") in FILE_EVIDENCE_TYPES:
                if len(hash_val) != 64:
                    errors.append(f"[CR-2] {eid}: file evidence requires a real SHA-256 content_hash at Locked.")
            else:
                if not custody.strip() or "tbd" in custody.lower() or "pending" in custody.lower():
                    errors.append(f"[CR-2] {eid}: non-file evidence requires resolvable custody at Locked.")
            if not e.get("classification"):
                errors.append(f"[CR-2] {eid}: evidence classification required at Locked.")

    # CR-3 — human approval at Locked
    if status_l == "locked":
        approvals = pdr.get("approvals", []) or []
        if not any(a.get("decision") == "Approved" for a in approvals):
            errors.append("[CR-3] Locked record has no human approval with decision=Approved.")

    # CR-4 (PF-1) — temporal scope binds at Locked
    atype = (pdr.get("decision_artifact") or {}).get("type", "")
    timeline = pdr.get("timeline")
    placements = (timeline or {}).get("placements") or []
    if atype in TEMPORAL_TYPES and status_l == "locked" and (not timeline or not placements):
        errors.append(f"[CR-4] Locked record of temporal type '{atype}' requires timeline with >=1 placement.")
    if atype in NON_TEMPORAL_TYPES and timeline:
        errors.append(f"[CR-4] artifact type '{atype}' is non-temporal; timeline must be omitted.")
    if atype and atype not in REGISTERED_TYPES:
        errors.append(f"[CR-4/vocab] artifact type '{atype}' is not in the registered type vocabulary.")

    # CR-5 (§6a) — transition chain from Draft to current status
    if status_l != INITIAL_STATE:
        if not transitions:
            errors.append(f"[CR-5] status '{status}' with no transition chain (§6a).")
        else:
            if str(transitions[0].get("from", "")).lower() != INITIAL_STATE:
                errors.append("[CR-5] transition chain must begin at Draft.")
            for i in range(1, len(transitions)):
                if transitions[i].get("from") != transitions[i - 1].get("to"):
                    errors.append(f"[CR-5] broken chain at entry {i}: from '{transitions[i].get('from')}' != prior to '{transitions[i-1].get('to')}'.")
            if transitions and str(transitions[-1].get("to", "")).lower() != status_l:
                errors.append(f"[CR-5] chain ends at '{transitions[-1].get('to')}' but status is '{status}'.")
    return errors


def validate_file(path: Path) -> int:
    record = yaml.safe_load(path.read_text())
    errs = structural_errors(record) + conditional_errors(record)
    if errs:
        print(f"FAIL  {path.name} — {len(errs)} violation(s):")
        for e in errs:
            print(f"      {e}")
        return 1
    print(f"PASS  {path.name}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    rc = 0
    for arg in sys.argv[1:]:
        rc |= validate_file(Path(arg))
    sys.exit(rc)
